import './App.css';
import AddForm from './components/AddForm';
import Listing from './components/Listing';

function App() {
  return (
    <div className="App">
        <AddForm/>
        <Listing/>
    </div>
  );
}

export default App;
