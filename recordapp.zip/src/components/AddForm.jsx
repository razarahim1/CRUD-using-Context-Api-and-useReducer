import React from 'react'

function AddForm() {
  return (
    <div className="form-fields">
            <form>
                <div className="form-data">
                <p style={{display:"inline-block",width:"55%"}}>Add Record</p>     
                    <input 
                     type="text"
                     placeholder="Enter title..." 
                     className="input-field" />
                    
                    <input 
                    type="text" 
                    placeholder="Enter upvotes number between 0 to 100.." 
                    className="input-field" />
                    
                    <input 
                    type="text" 
                    placeholder="Enter Date.." 
                    className="input-field" />
                    
                    <button 
                    className="add-data-btn">Add Data</button>
                </div>
            </form>
            </div>

  )
}

export default AddForm