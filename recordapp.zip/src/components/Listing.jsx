import React from 'react'

function Listing() {
  return (
    <div className="form-fields2">
                <input type="text" className="input-field" 
                  placeholder="Search the record"
                />
                <span>Sort By</span>
                <button className="sort-button">Most Updated</button>
                <button className="sort-button">Most Recent</button>
                <table>
                  <tr>
                    <th>Title</th>
                    <th>Upvotes</th>
                    <th>Date</th>
                    <th></th>
                  </tr>
                  <tr>
                    <td>Scaling to 100k Users</td>
                    <td>72</td>
                    <td>2019-01-21</td>
                    <td>
                      <button className="button-actions view">View</button>
                      <button className="button-actions edit">Edit</button>
                      <button className="button-actions delete">Delete</button>
                    </td>
                  </tr>
                  <tr>
                    <td>Scaling to 100k Users</td>
                    <td>72</td>
                    <td>2019-01-21</td>
                    <td>
                      <button className="button-actions view">View</button>
                      <button className="button-actions edit">Edit</button>
                      <button className="button-actions delete">Delete</button>
                    </td>
                  </tr>
                  <tr>
                    <td>Scaling to 100k Users</td>
                    <td>72</td>
                    <td>2019-01-21</td>
                    <td>
                      <button className="button-actions view">View</button>
                      <button className="button-actions edit">Edit</button>
                      <button className="button-actions delete">Delete</button>
                    </td>
                  </tr>
                </table>
                                   
                  
                </div>

  )
}

export default Listing